import PlayerProfile from "@/components/MessiUpdate/MessiUpdate";

export default function PlayerProfilePage() {
  return <PlayerProfile />;
}