import PlayerProfile from "@/components/MessiPreview/MessiPreview";

export default function PlayerProfilePage() {
  return <PlayerProfile />;
}