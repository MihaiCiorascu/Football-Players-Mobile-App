import PlayerProfile from "@/components/NewPlayerStats/NewPlayerStats";

export default function PlayerProfilePage() {
  return <PlayerProfile />;
}
