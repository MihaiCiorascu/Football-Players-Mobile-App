import PlayerProfile from "@/components/FullList/FullList";

export default function PlayerProfilePage() {
  return <PlayerProfile />;
}
