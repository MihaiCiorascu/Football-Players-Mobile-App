import PlayerProfile from "@/components/NewPlayerPreview/NewPlayerPreview";

export default function PlayerProfilePage() {
  return <PlayerProfile />;
}
