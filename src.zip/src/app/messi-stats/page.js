import PlayerProfile from "@/components/MessiStats/MessiStats";

export default function PlayerProfilePage() {
  return <PlayerProfile />;
}