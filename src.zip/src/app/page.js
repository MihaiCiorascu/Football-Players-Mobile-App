import InputDesign from "../components/MainPage/InputDesign";

export default function Home() {
  return (
    <div>
      <InputDesign />
    </div>
  );
}
