// "use client";
// import React from "react";
// import styles from "./NewPlayerStats.module.css";

// const SaveButton = ({ onClick }) => {
//   return (
//     <button className={styles.saveButton} onClick={onClick}>
//       SAVE CHANGES
//     </button>
//   );
// };

// export default SaveButton;
"use client";
import React from "react";
import { usePlayer } from "C:/Users/Mihai/football-players-web/src/context/PlayerContext.jsx";
import styles from "./NewPlayerStats.module.css";

const SaveButton = ({ playerData }) => {
  const { addPlayer } = usePlayer();

  const handleSave = () => {
    const newPlayer = {
      id: Date.now(), // Unique ID
      name: `${playerData.firstName} ${playerData.lastName}`,
      position: playerData.position || "Unknown Position",
      rating: "0",
      ratingColor: "red",
      number: playerData.playerNumber || "-",
      link: "/player/new", // Adjust this based on routing
      image: "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2Fb17a7bfed461553f6be1a921288e1c35c2749b1db9c45baf0fb5107350e5fee1"
    };

    addPlayer(newPlayer); // ✅ Add to list

    alert("New player added!");
    window.location.href = "/"; // Redirect after saving
  };

  return (
    <button className={styles.saveButton} onClick={handleSave}>
      SAVE CHANGES
    </button>
  );
};

export default SaveButton;
