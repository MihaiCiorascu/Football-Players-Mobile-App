// "use client";
// import React, { useEffect, useState } from "react";
// import PlayerHeader from "./PlayerHeader";
// import StatsSection from "./StatsSection";
// import SaveButton from "./SaveButton";
// import { usePlayerStore } from "@/components/playerStore";
// import styles from "./NewPlayerStats.module.css";

// function NewPlayerStats() {
//   const addPlayer = usePlayerStore((state) => state.addPlayer); // Get function to add player
  
//   const [playerData, setPlayerData] = useState({
//     firstName: "",
//     lastName: "Last Name",
//     playerNumber: "",
//     goals: "0",
//     age: "",
//     position: "",
//     playerImageUrl:
//       "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2Fb17a7bfed461553f6be1a921288e1c35c2749b1db9c45baf0fb5107350e5fee1",
//   });

//   const positionMap = {
//     ST: "Striker",
//     CF: "Center Forward",
//     LW: "Left Winger",
//     RW: "Right Winger",
//     LM: "Left Midfielder",
//     RM: "Right Midfielder",
//     CAM: "Center Attacking Midfielder",
//     CM: "Center Midfielder",
//     CDM: "Defensive Midfielder",
//     LB: "Left Back",
//     RB: "Right Back",
//     CB: "Center Back",
//     GK: "Goalkeeper",
//   };

//   useEffect(() => {
//     const params = new URLSearchParams(window.location.search);
//     setPlayerData({
//       firstName: params.get("firstName")?.trim() || "",
//       lastName: params.get("lastName")?.trim() || "Last Name",
//       playerNumber: params.get("shirtNumber") || "",
//       goals: "0",
//       age: params.get("age") || "",
//       position: positionMap[params.get("position")] || "",
//       playerImageUrl:
//         "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2Fb17a7bfed461553f6be1a921288e1c35c2749b1db9c45baf0fb5107350e5fee1",
//     });
//   }, []);

//   const handleSaveChanges = () => {
//     if (!playerData.firstName && !playerData.lastName) return;

//     const newPlayer = {
//       name: `${playerData.firstName} ${playerData.lastName}`.trim(),
//       position: playerData.position,
//       image: playerData.playerImageUrl,
//     };

//     addPlayer(newPlayer); // Add to in-memory store
//     setTimeout(() => {
//         window.location.href = "/full-list";
//       }, 200);
//   };

//   return (
//     <main className={styles.container}>
//       <PlayerHeader
//         firstName={playerData.firstName}
//         lastName={playerData.lastName}
//         playerNumber={playerData.playerNumber}
//         playerImageUrl={playerData.playerImageUrl}
//       />
//       <StatsSection
//         goals={playerData.goals}
//         age={playerData.age}
//         position={playerData.position}
//       />
//       <SaveButton onClick={handleSaveChanges} />
//     </main>
//   );
// }

// export default NewPlayerStats;


"use client";
import React, { useEffect, useState } from "react";
import PlayerHeader from "./PlayerHeader";
import StatsSection from "./StatsSection";
import SaveButton from "./SaveButton";
import styles from "./NewPlayerStats.module.css";

function NewPlayerStats() {
  const [playerData, setPlayerData] = useState({
    firstName: "First Name",
    lastName: "Last Name",
    playerNumber: "",
    goals: "0",
    age: "",
    position: "",
    playerImageUrl:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/33367e44c5ed17e458231156d84d8eadd7d5b485",
  });

  useEffect(() => {
    // Get URL parameters when component mounts
    const params = new URLSearchParams(window.location.search);

    // Log received parameters for debugging
    console.log("Stats page received params:", {
      firstName: params.get("firstName"),
      lastName: params.get("lastName"),
      shirtNumber: params.get("shirtNumber"),
      age: params.get("age"),
      position: params.get("position"),
    });

    setPlayerData({
        firstName: params.get("firstName")?.trim() || "",
        lastName: params.get("lastName")?.trim() || "Last Name",
        playerNumber: params.get("shirtNumber") || "",
        goals: "0", 
        age: params.get("age") || "",
        position: params.get("position") || "",
        playerImageUrl: "https://cdn.builder.io/api/v1/image/assets/TEMP/33367e44c5ed17e458231156d84d8eadd7d5b485",
    });
  }, []);

  const handleSaveChanges = () => {
    // Handle save logic here
    console.log("Saving changes...");
    // Navigate back to the dashboard or another page
    window.location.href = "/";
  };

  return (
    <main className={styles.container}>
      <PlayerHeader
        firstName={playerData.firstName}
        lastName={playerData.lastName}
        playerNumber={playerData.playerNumber}
        playerImageUrl={playerData.playerImageUrl}
      />
      <StatsSection
        goals={playerData.goals}
        age={playerData.age}
        position={playerData.position}
      />
      {/* <SaveButton onClick={handleSaveChanges} /> */}
      <SaveButton playerData={playerData} />
    </main>
  );
}

export default NewPlayerStats;
