"use client";
import React from "react";
import styles from "./MessiStats.module.css";

// Stat Box Component
const StatBox = ({ value, label, className, valueClassName }) => {
  return (
    <div className={className}>
      <h2 className={valueClassName}>{value}</h2>
      <hr className={styles.statDivider} />
      <p className={styles.statLabel}>{label}</p>
    </div>
  );
};

// Team Logos Component
const TeamLogos = () => {
  return (
    <div className={styles.teamLogosContainer}>
      <img
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/b7ea6dbd8bb4348887784cc8e36a8baf95caa18dfc8712175a70391f7b5f1d41"
        alt="Team logo"
        className={styles.smallTeamLogo}
      />
      <div className={styles.logoGroup}>
        <img
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/c505045ce833140be0f4c3e8a7a0d1bbb2bdc7c2f5fc31761f31c35afa7a7fd8"
          alt="Team logo"
          className={styles.mediumTeamLogo}
        />
        <img
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/57ee7e7733207ac3f88aa4cd9a357a63bfb113df9b151e5545e95d3077403be7"
          alt="Team logo"
          className={styles.mediumTeamLogo}
        />
      </div>
    </div>
  );
};

function MessiStats() {
  const handleEditClick = () => {
    window.location.href = "/messi-update"; // Change this to your update page route
  };

  return (
    <article className={styles.lionelMessiStats}>
      <header className={styles.header}>
        <img
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/c0146b2f6e217c3d4efe93b433edb290537dd8c72f38cd17c2684b8f9e5a1aa0"
          alt="Lionel Messi"
          className={styles.headerImage}
        />
        <button
          className={styles.editButton}
          onClick={handleEditClick}
          aria-label="Edit player"
        >
          <img
            src="https://cdn-icons-png.flaticon.com/512/1159/1159633.png" 
            alt="Edit icon"
            className={styles.editIcon}
          />
        </button>
      </header>

      <section className={styles.contentContainer}>
        <div className={styles.statsContainer}>
          <StatBox
            value="851"
            label="Goals"
            className={styles.statBox}
            valueClassName={styles.statValue}
          />
          <StatBox
            value="37"
            label="Age"
            className={styles.statBox}
            valueClassName={styles.statValue}
          />
          <StatBox
            value="CF"
            label="Position"
            className={styles.positionStatBox}
            valueClassName={styles.statValue}
          />
        </div>

        <h3 className={styles.teamsHeading}>Teams Played for</h3>
        <TeamLogos />
      </section>
    </article>
  );
}

export default MessiStats;


// "use client";

// import React from "react";
// import { usePlayer } from "C:/Users/Mihai/football-players-web/src/context/PlayerContext.jsx"; // Import context
// import styles from "./MessiStats.module.css";

// function MessiStats() {
//   const { player } = usePlayer(); // Get updated player data

//   return (
//     <article className={styles.lionelMessiStats}>
//       <header>
//         <img
//           src="https://cdn.builder.io/api/v1/image/assets/TEMP/c0146b2f6e217c3d4efe93b433edb290537dd8c72f38cd17c2684b8f9e5a1aa0?placeholderIfAbsent=true&apiKey=6c19a84570cc4b7ebcefc63534859305"
//           alt={player.name}
//           className={styles.headerImage}
//         />
//       </header>

//       <section className={styles.contentContainer}>
//         <h1 className={styles.playerName}>{player.name}</h1>
//         <h2 className={styles.jerseyNumber}>#{player.number}</h2>
//       </section>
//     </article>
//   );
// }

// export default MessiStats;
