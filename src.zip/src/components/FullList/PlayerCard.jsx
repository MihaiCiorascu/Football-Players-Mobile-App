// "use client";
// import React from "react";
// import styles from "./PlayerCard.module.css";

// const PlayerCard = ({
//   image,
//   name,
//   position,
//   rating,
//   ratingColor,
//   link,
//   onDelete
// }) => {
//   const getRatingStyle = () => {
//     switch (ratingColor) {
//       case "yellow":
//         return styles.ratingYellow;
//       case "blue":
//         return styles.ratingBlue;
//       default:
//         return styles.ratingGreen;
//     }
//   };

//   const handleClick = (e) => {
//     // Prevent navigation when clicking the delete button
//     if (e.target.closest(`.${styles.deleteButton}`)) return;
//     window.location.href = link;
//   };

//   return (
//     <article className={styles.playerCard} role="button" tabIndex={0} onClick={handleClick}>
//       <button className={styles.deleteButton} onClick={onDelete} aria-label="Delete player">
//         -
//       </button>
//       <div className={styles.playerInfo}>
//         <img src={image} alt={`${name} profile`} className={styles.playerImage} />
//         <div className={styles.playerDetails}>
//           <h3 className={styles.playerName}>{name}</h3>
//           <p className={styles.playerDescription}>{position}</p>
//         </div>
//         <div className={`${styles.ratingBadge} ${getRatingStyle()}`}>
//           {rating}
//         </div>
//       </div>
//     </article>
//   );
// };

// export default PlayerCard;

"use client";

import React from "react";
import styles from "./PlayerCard.module.css";

const PlayerCard = ({ player, onDelete }) => {
  if (!player) {
    return null; // ✅ Prevents crashing if player is undefined
  }

  const getRatingStyle = () => {
    switch (player.ratingColor) {
      case "yellow":
        return styles.ratingYellow;
      case "blue":
        return styles.ratingBlue;
      default:
        return styles.ratingGreen;
    }
  };

  const handleClick = (e) => {
    if (e.target.closest(`.${styles.deleteButton}`)) return;
    window.location.href = player.link;
  };

  return (
    <article className={styles.playerCard} role="button" tabIndex={0} onClick={handleClick}>
      <button className={styles.deleteButton} onClick={onDelete} aria-label="Delete player">
        -
      </button>
      <div className={styles.playerInfo}>
        {player.image ? (
          <img src={player.image} alt={`${player.name} profile`} className={styles.playerImage} />
        ) : (
          <div className={styles.placeholderImage}>No Image</div> // ✅ Placeholder if no image
        )}
        <div className={styles.playerDetails}>
          <h3 className={styles.playerName}>{player.name}</h3>
          <p className={styles.playerDescription}>{player.position}</p>
        </div>
        <div className={`${styles.ratingBadge} ${getRatingStyle()}`}>
          {player.rating}
        </div>
      </div>
    </article>
  );
};

export default PlayerCard;
