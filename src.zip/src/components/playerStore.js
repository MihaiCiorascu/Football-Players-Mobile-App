"use client";
import { create } from "zustand";

export const usePlayerStore = create((set) => ({
  players: [
    {
        image: "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2Fdde248022a08ce177cea0ae2341e3eb74eb577bfa408c8d125ba1b93b21acd80",
        name: "Lionel Messi",
        position: "Center Forward",
        rating: "8.7",
        ratingColor: "green",
        link: "/player/messi"
    },
    {
        image: "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2F3466aecfdafcf7165fa5d1540bb46d20dffad75fafa265495ded188b0d7299a3",
        name: "Paulo Dybala",
        position: "Center Attacking Midfielder",
        rating: "8.1",
        ratingColor: "green",
        link: "/player/dybala"
    },
    {
        image: "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2F2a5b6f4961a76265d01cc3235fd2eefce7ce23c60d7194c0e7f5de5afe4aff42",
        name: "Cristiano Ronaldo",
        position: "Striker",
        rating: "7.9",
        ratingColor: "yellow",
        link: "/player/ronaldo"
    },
    {
        image: "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2Fd5463b11cd2f1ab183d2750d1d50f6d64909092cfe3206096fc9c061252e30b2",
        name: "Lamine Yamal",
        position: "Right Winger",
        rating: "9.4",
        ratingColor: "blue",
        link: "/player/yamal"
    },
    {
        image: "https://cdn.builder.io/api/v1/image/assets%2F6c19a84570cc4b7ebcefc63534859305%2F23aef36b2afc9bc198b4eece02395cc8e3319f547b66d21bddeab5f66f783970",
        name: "Pedri",
        position: "Center Midfielder",
        rating: "9.0",
        ratingColor: "blue",
        link: "/player/pedri"
    },
    {
        name: "Radu Dragusin",
        position: "Center Back",
        image:
            "https://cdn.builder.io/api/v1/image/assets/TEMP/6f42d19d337d35a53e290fc9f121ede2b8f322a28f4059e746fb20f1a7b96889?placeholderIfAbsent=true&apiKey=6c19a84570cc4b7ebcefc63534859305",
    },
    {
        name: "Florinel Coman",
        position: "Left Midfielder",
        image:
            "https://cdn.builder.io/api/v1/image/assets/TEMP/4f91d6d34742cc282e1a75b7630953d2ae8d76178960254d98aa02ea53ee2596?placeholderIfAbsent=true&apiKey=6c19a84570cc4b7ebcefc63534859305",
    },
  ],

  addPlayer: (newPlayer) =>
    set((state) => ({ players: [...state.players, newPlayer] })),
}));
