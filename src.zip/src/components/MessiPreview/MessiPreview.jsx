// "use client";
// import * as React from "react";
// import { useState, useEffect } from "react";
// import styles from "./MessiPreview.module.css";

// function MessiPreview() {
//   const [player, setPlayer] = useState(() => ({
//     firstName: "LIONEL",
//     lastName: "MESSI",
//     imageUrl: "/images/messi1.png"
//     }));

//   const [formData, setFormData] = useState({
//     age: "37",
//     position: "CF",
//     shirtNumber: "10",
//   });

//   useEffect(() => {
//     const age = "37";
//     const position = "CF";
//     const shirtNumber = "10";

//     setFormData({
//       age,
//       position,
//       shirtNumber,
//     });

//     console.log("Received player data:", {
//       firstName: player.firstName,
//       lastName: player.lastName,
//       age,
//       position,
//       shirtNumber,
//     });
//   }, []);

//   const handleStatsClick = () => {
//     const queryParams = new URLSearchParams({
//       firstName: player.firstName,
//       lastName: player.lastName,
//       shirtNumber: formData.shirtNumber,
//       age: formData.age,
//       position: formData.position,
//     }).toString();

//     window.location.href = `/messi-stats?${queryParams}`;
//   };

//   return (
//     <section className={styles.playerCardContainer}>
//       <article className={styles.div}>
//         <header className={styles.div2}>
//           <h2 className={styles.div3}>{player.firstName}</h2>
//           <h1 className={styles.div4}>{player.lastName}</h1>
//           <figure className={styles.div5}>
//             <img
//               src="/messi1.png"
//               alt="Player profile"
//               className={styles.img}
//             />
//             <div className={styles.div6} />
//           </figure>
//           <button
//             className={styles.div7}
//             aria-label="View career statistics"
//             onClick={handleStatsClick}
//             onKeyDown={(e) => {
//               if (e.key === "Enter" || e.key === " ") {
//                 handleStatsClick();
//               }
//             }}
//           >
//             <div>
//               <svg className="w-[24px] h-[24px]" viewBox="0 0 24 24">
//                 <path
//                   d="M95.5 805.8H100V820.5H95.5V805.8ZM103.9 799.5H108.1V820.5H103.9V799.5ZM112.3 811.5H116.5V820.5H112.3V811.5Z"
//                   fill="#6923B8"
//                 ></path>
//               </svg>
//             </div>
//             <span className={styles.div8}>VIEW CAREER STATS</span>
//           </button>
//         </header>
//       </article>
//     </section>
//   );
// }

// export default MessiPreview;

"use client";

import React from "react";
import { usePlayer } from "C:/Users/Mihai/football-players-web/src/context/PlayerContext.jsx"; // Import context
import styles from "./MessiPreview.module.css";

function MessiPreview() {
  const { players } = usePlayer();
  const player = players.find((p) => p.id === 1); // ✅ Get updated Messi data

  if (!player) {
    return <p>Player not found</p>; // Fallback if player is missing
  }

  const handleStatsClick = () => {
    const queryParams = new URLSearchParams({
      firstName: player.name.split(" ")[0], // Extract first name
      lastName: player.name.split(" ").slice(1).join(" "), // Extract last name
      shirtNumber: player.number,
      age: "37",
      position: "CF",
    }).toString();

    window.location.href = `/messi-stats?${queryParams}`;
  };

  return (
    <section className={styles.playerCardContainer}>
      <article className={styles.div}>
        <header className={styles.div2}>
          <h2 className={styles.div3}>{player.name.split(" ")[0]}</h2>
          <h1 className={styles.div4}>{player.name.split(" ").slice(1).join(" ")}</h1>
          <figure className={styles.div5}>
            <img
              src="/messi1.png"
              alt="Player profile"
              className={styles.img}
            />
            <div className={styles.div6} />
          </figure>
          <button
            className={styles.div7}
            aria-label="View career statistics"
            onClick={handleStatsClick}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                handleStatsClick();
              }
            }}
          >
            <div>
              <svg className="w-[24px] h-[24px]" viewBox="0 0 24 24">
                <path
                  d="M95.5 805.8H100V820.5H95.5V805.8ZM103.9 799.5H108.1V820.5H103.9V799.5ZM112.3 811.5H116.5V820.5H112.3V811.5Z"
                  fill="#6923B8"
                ></path>
              </svg>
            </div>
            <span className={styles.div8}>VIEW CAREER STATS</span>
          </button>
        </header>
      </article>
    </section>
  );
}

export default MessiPreview;
