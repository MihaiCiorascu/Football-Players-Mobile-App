// "use client";
// import * as React from "react";
// import { useState } from "react";
// import styles from "./MessiUpdate.module.css";

// function MessiUpdate() {
//   const [playerName, setPlayerName] = useState("Lionel Messi");
//   const [playerNumber, setPlayerNumber] = useState("10");

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     // In a real application, you would handle the form submission here
//     // For example, saving data to a database or API
//     console.log("Form submitted with:", { playerName, playerNumber });

//     // Navigate to another page
//     // In a real application, you would use your framework's navigation method
//     // For example, with Next.js: router.push('/success')
//     alert(
//       "Form submitted! Would navigate to another page in a real application.",
//     );
//   };

//   return (
//     <section className={styles.frame}>
//       <img
//         src="https://cdn.builder.io/api/v1/image/assets/TEMP/fc1abbe6588a161b134f5c3dc66bf033ef0cddbbff0c6c200552168344ba15ca?placeholderIfAbsent=true&apiKey=6c19a84570cc4b7ebcefc63534859305"
//         className={styles.headerImage}
//         alt="Player profile header"
//       />

//       <form className={styles.formContainer} onSubmit={handleSubmit}>
//         <div className={styles.formGroup}>
//           <label htmlFor="playerName" className={styles.label}>
//             Player Name
//           </label>
//           <input
//             id="playerName"
//             type="text"
//             className={styles.input}
//             value={playerName}
//             onChange={(e) => setPlayerName(e.target.value)}
//             required
//           />
//         </div>

//         <div className={styles.formGroup}>
//           <label htmlFor="playerNumber" className={styles.label}>
//             Jersey Number
//           </label>
//           <input
//             id="playerNumber"
//             type="number"
//             className={styles.input}
//             value={playerNumber}
//             onChange={(e) => setPlayerNumber(e.target.value)}
//             min="1"
//             max="99"
//             required
//           />
//         </div>

//         <button type="submit" className={styles.saveButton}>
//           SAVE CHANGES
//         </button>
//       </form>
//     </section>
//   );
// }

// export default MessiUpdate;


"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { usePlayer } from "C:/Users/Mihai/football-players-web/src/context/PlayerContext.jsx"; // Import context
import styles from "./MessiUpdate.module.css";

function MessiUpdate() {
  const { players, updatePlayer } = usePlayer();
  const player = players.find((p) => p.id === 1); 
  const [newPlayerName, setNewPlayerName] = useState(player.name);
  const [newPlayerNumber, setNewPlayerNumber] = useState(player.number);

  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();
    updatePlayer(1, newPlayerName, newPlayerNumber); // Update in-memory state
    alert("Player data updated!");
    router.push("/full-list");
  };

  return (
    <section className={styles.frame}>
      <img
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/fc1abbe6588a161b134f5c3dc66bf033ef0cddbbff0c6c200552168344ba15ca?placeholderIfAbsent=true&apiKey=6c19a84570cc4b7ebcefc63534859305"
        className={styles.headerImage}
        alt="Player profile header"
      />

      <form className={styles.formContainer} onSubmit={handleSubmit}>
        <div className={styles.formGroup}>
          <label htmlFor="playerName" className={styles.label}>
            Player Name
          </label>
          <input
            id="playerName"
            type="text"
            className={styles.input}
            value={newPlayerName}
            onChange={(e) => setNewPlayerName(e.target.value)}
            required
          />
        </div>

        <div className={styles.formGroup}>
          <label htmlFor="playerNumber" className={styles.label}>
            Jersey Number
          </label>
          <input
            id="playerNumber"
            type="number"
            className={styles.input}
            value={newPlayerNumber}
            onChange={(e) => setNewPlayerNumber(e.target.value)}
            min="1"
            max="99"
            required
          />
        </div>

        <button type="submit" className={styles.saveButton}>
          SAVE CHANGES
        </button>

         {/* <button className={styles.fullListButton} onClick={() => router.push("/full-list")}>
            View Full List
        </button> */}
      </form>
    </section>
  );
}

export default MessiUpdate;
