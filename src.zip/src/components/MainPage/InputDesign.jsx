"use client";
import React, { useState } from "react";
import styles from "./InputDesign.module.css";
import SearchBar from "./SearchBar";
import PlayerCard from "./PlayerCard";
import CreatePlayerForm from "./CreatePlayerForm";
import { usePlayer } from "C:/Users/Mihai/football-players-web/src/context/PlayerContext.jsx";

function InputDesign() {
    const { players} = usePlayer(); // ✅ Get players from context
    const [searchTerm, setSearchTerm] = useState("");

  const handleStatsClick = () => {
    window.location.href = "/full-list";
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
  };

  const filteredPlayers = players
    .filter(player =>
      player.name.toLowerCase().startsWith(searchTerm.toLowerCase())
    )
    .slice(0, 5);

  return (
    <div className={styles.pageWrapper}>
      <link
        href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;600;700;800&family=League+Gothic&display=swap"
        rel="stylesheet"
      />
      <div className={styles.boxContainer}>
        <main className={styles.container}>
          <header>
            <p className={styles.greeting}>Hello!</p>
            <h1 className={styles.welcomeHeading}>Welcome Back!</h1>
          </header>

          <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />

          <section>
            <h2 className={styles.sectionHeading}>
              Recent Player Performances
            </h2>
            <div className={styles.performanceContainer}>
              {filteredPlayers.length > 0 ? (
                filteredPlayers.map((player, index) => (
                  <PlayerCard
                    key={index}
                    image={player.image}
                    name={player.name}
                    position={player.position}
                    rating={player.rating}
                    ratingColor={player.ratingColor}
                    link={player.link}
                  />
                ))
              ) : (
                <p className={styles.noResults}>No players found matching "{searchTerm}"</p>
              )}
            </div>

            <footer
              className={styles.statsFooter}
              onClick={handleStatsClick}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  handleStatsClick();
                }
              }}
            >
              See full stats
            </footer>
          </section>

          <section>
            <h2 className={styles.sectionHeading}>Create a Player</h2>
            <CreatePlayerForm />
          </section>
        </main>
      </div>
    </div>
  );
}

export default InputDesign;
