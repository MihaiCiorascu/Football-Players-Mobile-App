"use client";
import React from "react";
import styles from "./PlayerCard.module.css";

const PlayerCard = ({
  image,
  name,
  position,
  rating,
  ratingColor,
  link,
}) => {
  const getRatingStyle = () => {
    switch (ratingColor) {
      case "yellow":
        return styles.ratingYellow;
      case "blue":
        return styles.ratingBlue;
      default:
        return styles.ratingGreen;
    }
  };

  const handleClick = () => {
    window.location.href = link;
  };

  return (
    <article
      className={styles.playerCard}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          handleClick();
        }
      }}
    >
      <div className={styles.playerInfo}>
        <img
          src={image}
          alt={`${name} profile`}
          className={styles.playerImage}
        />
        <div className={styles.playerDetails}>
          <h3 className={styles.playerName}>{name}</h3>
          <p className={styles.playerPosition}>{position}</p>
        </div>
        <div className={`${styles.ratingBadge} ${getRatingStyle()}`}>
          {rating}
        </div>
      </div>
    </article>
  );
};

export default PlayerCard;
